package christmasPastryShop.common.enums;

public enum BoothType {
    OpenBooth,
    PrivateBooth
}
