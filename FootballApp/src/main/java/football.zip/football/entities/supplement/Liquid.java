package football.entities.supplement;

public class Liquid extends BaseSupplement{
    private static final int ENERGY = 90;
    private static final int PRICE = 25;
    public Liquid() {
        super(ENERGY, PRICE);
    }
}
