package zoo.core;

public interface Engine extends Runnable {
}
